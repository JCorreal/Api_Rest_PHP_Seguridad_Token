<?php // Este es el Controlador Manager general de todo el sistema. Todo tiene que pasar por esta clase
     require_once 'dal/AccesoDatos.php';       
     
 class Controlador  {
    
    protected $iaccesoDatos;
    
    public function __construct(IAccesodatos $iaccesoDatos)
    {
        $this->iaccesoDatos=new AccesoDatos();
    }             
  
    public function solicitarIngreso($username, $clave) 
    {
       return $this->iaccesoDatos->obtenerAcceso($username, $clave);
    }
    
    public function obtenerListadoEmpleados() 
    {
       return $this->iaccesoDatos->obtenerListadoEmpleados();
    }
    
    public function obtenerEmpleado($DatoBuscar)
    {
        return $this->iaccesoDatos->obtenerEmpleado($DatoBuscar);
    }
    
    public function guardarEmpleado ($Object)
    {
       return $this->iaccesoDatos->guardarEmpleado($Object); 
    }
    
    public function eliminarEmpleado ($DatoEliminar)
    {
       return $this->iaccesoDatos->eliminarEmpleado($DatoEliminar); 
    }
 }
