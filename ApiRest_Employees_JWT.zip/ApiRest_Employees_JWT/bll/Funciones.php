<?php // Esta es una clase transversal, desde donde se instancia el Factory Method
     require_once 'bll/Controlador.php';
     require_once 'bll/AccesoDatosFactory.php';      
     
     const DOMINIO = "http://localhost/ApiRest_Employees_JWT/index.php/";
     
     // Constantes de errores 
     const OK = 200;
     const MOVED_PERMANENTLY = 301;
     const FOUND = 302;
     const UNAUTHORIZED = 401;
     const FORBIDDEN = 403;
     const NOT_FOUND = 404;
     const METHOD_NOT_ALLOWED = 405;
     const CONFLICT = 409;
     const UNPROCESSABLE_ENTITY = 422;
     const FAILED_DEPENDENCY = 424;
     const INTERNAL_SERVER_ERROR = 500;
     
     // Constantes de mensajes de respuesta
     const EXITOI = "El nuevo registro ha sido grabado";
     const EXITOU = "El nuevo registro ha sido actualizado";
     const EXITOD = "El registro ha sido eliminado";
     const ERRORDB = "Se ha producido un error accesando la base de datos";
     const ERRORUD = "No existe este usuario";
     const ERRORSD = "No hay datos json";
     const PERMISO = "Accesso denegado";
     const NUMERICO = "El id debe ser numerico";
     const CLAVEN = "Clave debe ser numerica de 6 digitos";
     const ERROREMAIL = "El email ya existe";
    
class Funciones
{   
   
   public static function crearControlador()
   {
        $accesodatos = new AccesoDatos();
        $accesodatos = AccesoDatosFactory::getAccesoDatos($accesodatos);       
        return new Controlador($accesodatos);
   }
}