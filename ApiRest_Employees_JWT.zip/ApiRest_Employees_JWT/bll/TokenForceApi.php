<?php // Este es el servicio Rest como tal, quien recibe las peticiones desde el exterior
     ini_set('display_errors', 1);
     ini_set('display_startup_errors', 1);
     error_reporting(E_ALL);
     require_once 'Funciones.php';       
     require_once 'bll/jwt_utils.php';
     require_once 'bo/Employee.php';
     
class TokenForceAPI {
    
    public function __construct(){}
             
    public function apiRest()
    {
        header('Content-Type: application/JSON');    
        $opcion = $_SERVER['REQUEST_METHOD'];
            
            switch ($opcion)
            {
            case 'GET':
                 $this->obtenerInformacion();
                 break;     
            case 'POST':
                 $this->agregarEmpleado();
                 break;                
            case 'PUT':
                 $this->actualizarEmpleado();
                 break;                         
            case 'DELETE':
                 $this->eliminarEmpleado();
                 break;
            default: 
                 echo 'Metodo No Valido';
                 break;
            }            
            
    }
    
    
 function obtenerInformacion(){  
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: GET"); 
            
    $bearer_token = get_bearer_token();
    $is_jwt_valid = is_jwt_valid($bearer_token);

    if($is_jwt_valid) 
    { 
        // **==**==**==**==**==**==**==**==**==**==**==**==**==**==**==**   
        $longitud = strlen(DOMINIO); 
        $host= $_SERVER["HTTP_HOST"];
        $url= $_SERVER["REQUEST_URI"];
        $miurl = "http://" . $host . $url;     
        $employee_id = substr($miurl, $longitud, strlen($miurl));
        // **==**==**==**==**==**==**==**==**==**==**==**==**==**==**==**    

        $controlador = Funciones::crearControlador(); 
        if (strlen($employee_id) > 0 ) 
        {
            $response = $controlador->obtenerEmpleado($employee_id);             
        }    
        else
        {
            $response = $controlador->obtenerListadoEmpleados();              
        }   
        echo json_encode($response, JSON_PRETTY_PRINT);  
    }
    else
    {
	echo json_encode(array('error' => 'Accesso denegado'));
    }
 }
 
 function agregarEmpleado()
 {
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: POST"); 
    
    $bearer_token = get_bearer_token();
    $is_jwt_valid = is_jwt_valid($bearer_token);

    if($is_jwt_valid) 
    {
        $obj = json_decode( file_get_contents('php://input') );   
        $objArr = (array)$obj;        
        if (empty($objArr))
        {
           $this->response(422,"Error","No hay datos json");                           
        }
        else
        {
               $employee = new Employee();    
               $employee->setEmployee_id(0);
               $employee->setFirst_name($obj->first_name);
               $employee->setLast_name($obj->last_name);
               $employee->setEmail($obj->email);
               $employee->setPhone_number($obj->phone_number);
               $employee->setHire_date($obj->hire_date);
               $employee->setJob_id($obj->job_id);
               $employee->setSalary($obj->salary);
               $employee->setCommission_pct($obj->commission_pct);
               $employee->setManager_id($obj->manager_id);
               $employee->setDepartment_id($obj->department_id);
               $controlador = Funciones::crearControlador();
               $resultado = $controlador->guardarEmpleado($employee); 
               if ($resultado == 0)
               {
                   $this->response(200,"Exito", "El nuevo registro ha sido grabado");
               }            
               else
               {
                   $this->response(200,"Error","Se ha producido un error accesando la base de datos");                         
               }                
        }
     }
     else 
     {
         echo json_encode(array('error' => 'Accesso denegado'));
     }
 }
 
 function actualizarEmpleado()
 {
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: PUT"); 
    
    $bearer_token = get_bearer_token();
    $is_jwt_valid = is_jwt_valid($bearer_token);
           
    if ($is_jwt_valid)
    {
        $obj = json_decode( file_get_contents('php://input') );   
        $objArr = (array)$obj;        
        if (empty($objArr))
        {
           $this->response(422,"Error","No hay datos json");                           
        }
        else
        {
               $employee = new Employee();    
               $employee->setEmployee_id($obj->employee_id);
               $employee->setFirst_name($obj->first_name);
               $employee->setLast_name($obj->last_name);
               $employee->setEmail($obj->email);
               $employee->setPhone_number($obj->phone_number);
               $employee->setHire_date($obj->hire_date);
               $employee->setJob_id($obj->job_id);
               $employee->setSalary($obj->salary);
               $employee->setCommission_pct($obj->commission_pct);
               $employee->setManager_id($obj->manager_id);
               $employee->setDepartment_id($obj->department_id);
               $controlador = Funciones::crearControlador();
               $resultado = $controlador->guardarEmpleado($employee); 
               if ($resultado == 0)
               {
                  $this->response(200,"Exito", "El registro ha sido actualizado"); 
                  
               }
               else if ($resultado == -2)
               {             
                  $this->response(200,"Error","No existe este usuario");
               }  
               else
               {
                   $this->response(200,"Error","Se ha producido un error accesando la base de datos");                         
               }  
        }
     }
     else 
     {
         echo json_encode(array('error' => 'Accesso denegado'));
     }
 }
 
 function eliminarEmpleado(){            
     // **==**==**==**==**==**==**==**==**==**==**==**==**==**==**==** 
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: DELETE"); 
    
    $bearer_token = get_bearer_token();
    $is_jwt_valid = is_jwt_valid($bearer_token);

    session_start();
    if (($is_jwt_valid) && ($_SESSION['PerfilAcceso'] == 'Admin'))
    { 
        $longitud = strlen(DOMINIO); 
        $host= $_SERVER["HTTP_HOST"];
        $url= $_SERVER["REQUEST_URI"];
        $miurl = "http://" . $host . $url;     
        $employee_id = substr($miurl, $longitud, strlen($miurl));
        // **==**==**==**==**==**==**==**==**==**==**==**==**==**==**==** 
        if (strlen($employee_id) > 0 ) 
        {
           $controlador = Funciones::crearControlador();
           $resultado = $controlador->eliminarEmpleado($employee_id);
           if ($resultado == 0)
           {
              $this->response(200,"Exito", "El registro ha sido eliminado");
           }
           else if ($resultado == -2)
           {             
              $this->response(200,"Error","No existe este usuario");
           }
           else
           {             
               $this->response(200,"Error","Se ha producido un error accesando la base de datos");
           }
        }
    }
     else 
     {
         echo json_encode(array('error' => 'Accesso denegado'));
     }    
 }
 
 
    function response($code=200, $status="", $message="") {
    http_response_code($code);
    if( !empty($status) && !empty($message) ){
        $response = array("status" => $status ,"message"=>$message);  
        echo json_encode($response,JSON_PRETTY_PRINT);    
    }            
 }   
}