<?php

 
class Employee implements JsonSerializable{
   
    private $employee_id = 0;
    private $first_name;
    private $last_name;
    private $email;
    private $phone_number;
    private $hire_date;
    private $job_id;
    private $salary;
    private $commission_pct;
    private $manager_id;
    private $department_id;
    
    public function getEmployee_id() {
        return $this->employee_id;
    }

    public function getFirst_name() {
        return $this->first_name;
    }

    public function getLast_name() {
        return $this->last_name;
    }

    public function getEmail() {
        return $this->email;
    }

    public function getPhone_number() {
        return $this->phone_number;
    }

    public function getHire_date() {
        return $this->hire_date;
    }

    public function getJob_id() {
        return $this->job_id;
    }

    public function getSalary() {
        return $this->salary;
    }

    public function getCommission_pct() {
        return $this->commission_pct;
    }

    public function getManager_id() {
        return $this->manager_id;
    }

    public function getDepartment_id() {
        return $this->department_id;
    }

    public function setEmployee_id($employee_id): void {
        $this->employee_id = $employee_id;
    }

    public function setFirst_name($first_name): void {
        $this->first_name = $first_name;
    }

    public function setLast_name($last_name): void {
        $this->last_name = $last_name;
    }

    public function setEmail($email): void {
        $this->email = $email;
    }

    public function setPhone_number($phone_number): void {
        $this->phone_number = $phone_number;
    }

    public function setHire_date($hire_date): void {
        $this->hire_date = $hire_date;
    }

    public function setJob_id($job_id): void {
        $this->job_id = $job_id;
    }

    public function setSalary($salary): void {
        $this->salary = $salary;
    }

    public function setCommission_pct($commission_pct): void {
        $this->commission_pct = $commission_pct;
    }

    public function setManager_id($manager_id): void {
        $this->manager_id = $manager_id;
    }

    public function setDepartment_id($department_id): void {
        $this->department_id = $department_id;
    }

    public function jsonSerialize(): mixed 
    {
        return 
        [
            'employee_id'   => $this->getEmployee_id(),
            'first_name'    => $this->getFirst_name(),
            'last_name'     => $this->getLast_name(),
            'email'         => $this->getEmail(),
            'phone_number'  => $this->getPhone_number(),
            'hire_date'     => $this->getHire_date(),
            'job_id'        => $this->getJob_id(),
            'salary'        => $this->getSalary(),
            'commission_pct'=> $this->getCommission_pct(),
            'manager_id'    => $this->getManager_id(),
            'department_id' => $this->getDepartment_id()
        ];
    }    

}
