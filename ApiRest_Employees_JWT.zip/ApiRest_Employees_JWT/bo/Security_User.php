<?php

class Security_User {
     
    private $user_id;
    private $username;
    private $password;
    private $profile;
    
    public function __construct() {}
    
    public function getUser_id() {
        return $this->user_id;
    }

    public function getUsername() {
        return $this->username;
    }

    public function getPassword() {
        return $this->password;
    }

    public function getProfile() {
        return $this->profile;
    }

    public function setUser_id($user_id): void {
        $this->user_id = $user_id;
    }

    public function setUsername($username): void {
        $this->username = $username;
    }

    public function setPassword($password): void {
        $this->password = $password;
    }

    public function setProfile($profile): void {
        $this->profile = $profile;
    }

}
