<?php // DAL: Data Access Layer - Capa Acceso Datos
             
    require_once 'bo/Employee.php';
    require_once 'bo/Security_User.php';
    require_once 'Conexion.php';
    require_once 'IAccesoDatos.php';

class AccesoDatos implements IAccesoDatos{
    
    private $cn = NULL;      // Alias para la Conexion
    private $vecr = array(); // Vector con Resultados
      
    public function obtenerAcceso($username, $clave) 
    {
        $usuario = new Security_User(); 
        $cn = Conexion::obtenerConexion();
        try
        { 
            $rs = $cn->query("CALL spr_R_ObtenerAcceso('" . $username . "', '" . $clave . "')");
            $fila = $rs->fetch_row();
            if ($fila != null)
            {
                $usuario->setUsername($fila[0]); 
                $usuario->setProfile($fila[1]);                 
            }
            else
            {
              $usuario = NULL;   
            }
            mysqli_free_result($rs);
            mysqli_close($cn);
            return $usuario;           
        }
        catch (Exception $ex)
        {
          echo $ex;
        }
    }
    
   private static function buscarRegistro($DatoBuscar)
   { // Funcion para buscar un registro especifico             
     try 
     {           
        $cn = Conexion::obtenerConexion();
        $rs= $cn->query("CALL spr_Listado_Employees('" . $DatoBuscar . "')");
        $vecresultado = array(); // Recorremos el resultado de la consulta y lo almacenamos en el array
        while ($fila = $rs->fetch_row()) 
        {
            array_push($vecresultado, $fila);                
        }
        mysqli_free_result($rs);
        mysqli_close($cn);
        return $vecresultado;
     }
     catch (Exception $ex)
     { 
       mysqli_close($cn);
       echo $ex;     
     }
   }
  
    public function obtenerEmpleado($DatoBuscar) {  
     try
     {         
          $vecr = AccesoDatos::buscarRegistro($DatoBuscar);
          if ($vecr!= NULL)
          {
            $employee = new Employee();
            $employee->setEmployee_id($vecr[0][0]);
            $employee->setFirst_name($vecr[0][1]);
            $employee->setLast_name($vecr[0][2]);
            $employee->setEmail($vecr[0][3]);
            $employee->setPhone_number($vecr[0][4]);
            $employee->setHire_date($vecr[0][5]);
            $employee->setJob_id($vecr[0][6]);
            $employee->setSalary($vecr[0][7]);
            $employee->setCommission_pct($vecr[0][8]);
            $employee->setManager_id($vecr[0][9]);
            $employee->setDepartment_id($vecr[0][10]);     
            $vecr = NULL;
            return $employee;
          }
          else
          {
              return NULL;
          }
       }
       catch (Exception $ex)
       {
           echo $ex;
       }   
    }


    public function obtenerListadoEmpleados() {
     $cn = Conexion::obtenerConexion();
     $DatoBuscar = 0;
     $ListaEmpleados = array();
     $vecr = array(); 
     try
     {
             $rs= $cn->query("CALL spr_Listado_Employees('" . $DatoBuscar . "')");  
             $i=0;
             while ($fila = $rs->fetch_row()) 
             {
                    array_push($vecr, $fila);   
                    $employee = new Employee();
                    $employee->setEmployee_id($vecr[$i][0]);
                    $employee->setFirst_name($vecr[$i][1]);
                    $employee->setLast_name($vecr[$i][2]);
                    $employee->setEmail($vecr[$i][3]);
                    $employee->setPhone_number($vecr[$i][4]);
                    $employee->setHire_date($vecr[$i][5]);
                    $employee->setJob_id($vecr[$i][6]);
                    $employee->setSalary($vecr[$i][7]);
                    $employee->setCommission_pct($vecr[$i][8]);
                    $employee->setManager_id($vecr[$i][9]);
                    $employee->setDepartment_id($vecr[$i][10]);  ;                   
                    array_push($ListaEmpleados, $employee);
                    $i++;
             }
             mysqli_free_result($rs);
             mysqli_close($cn);
             return $ListaEmpleados;
       }
       catch (Exception $ex)
       {
           echo $ex;
       }   
  }

    public function guardarEmpleado($employee)
    { 
        $cn = Conexion::obtenerConexion();
        try 
        {                   
            $cn->query("SET @result = 1");
            $cn->query("CALL spr_IUEmployees('" . $employee->getEmployee_id() . "',
                                             '" . $employee->getFirst_name() . "',
                                             '" . $employee->getLast_name() . "', 
                                             '" . $employee->getEmail() . "', 
                                             '" . $employee->getPhone_number() . "', 
                                             '" . $employee->getHire_date() . "',                                         
                                             '" . $employee->getJob_id() . "', 
                                             '" . $employee->getSalary() . "',
                                             '" . $employee->getCommission_pct() . "', 
                                             '" . $employee->getManager_id() . "', 
                                             '" . $employee->getDepartment_id() . "',                                                              
                                             @result)");

            $res = $cn->query("SELECT @result AS result");
            $row = $res->fetch_assoc();
            mysqli_close($cn);
            return $row['result'];          
        }
        catch (Exception $ex)
        {
            mysqli_close($cn);  
            echo $ex;
        }
    }
  
    public function eliminarEmpleado($DatoEliminar)
    {
     try
     {   
        $cn = Conexion::obtenerConexion();    
        $cn->query("SET @result = 1");
        $cn->query("CALL spr_DEmployee('" . $DatoEliminar . "',  @result)");

        $res = $cn->query("SELECT @result AS result");
        $row = $res->fetch_assoc();
        mysqli_close($cn);
        return $row['result'];
     }
     catch (Exception $ex)
     {
        mysqli_close($cn);
        echo $ex;
     }  
    }
}

?>


