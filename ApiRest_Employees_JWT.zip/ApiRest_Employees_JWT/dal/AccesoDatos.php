<?php // DAL: Data Access Layer - Capa Acceso Datos
             
    require_once 'bo/Employee.php';
    require_once 'bo/Security_User.php';
    require_once 'Conexion.php';
    require_once 'IAccesoDatos.php';

class AccesoDatos implements IAccesoDatos{
    
    private $cn = NULL;  // Alias para la Conexion
   
    public function obtenerAcceso($username, $clave) 
    {
        $usuario = new Security_User(); 
        $cn = Conexion::obtenerConexion();
        try
        { 
            if (is_numeric($clave)) 
            {
                $rs = $cn->query("CALL spr_R_ObtenerAcceso('" . $username . "', '" . $clave . "')");
                $fila = $rs->fetch_row();
                if ($fila != null)
                {
                    $usuario->setUsername($fila[0]); 
                    $usuario->setProfile($fila[1]);                 
                }                    
            }
            return $usuario;  
        }
        catch (Exception $ex)
        {
          echo $ex;
        }
    }
    
    public function obtenerEmpleado($employee_id) 
    {
        $employee = new Employee();
        $cn = Conexion::obtenerConexion();
        try
        {             
            $rs = $cn->query("CALL spr_Listado_Employees('" . $employee_id . "')");
            $row =  $rs->fetch_row();            
            if ($row != null)
            {                
                $employee->setEmployee_id($row[0]);
                $employee->setFirst_name($row[1]);
                $employee->setLast_name($row[2]);
                $employee->setEmail($row[3]);
                $employee->setPhone_number($row[4]);
                $employee->setHire_date($row[5]);
                $employee->setJob_id($row[6]);
                $employee->setSalary($row[7]);
                $employee->setCommission_pct($row[8]);
                $employee->setManager_id($row[9]);
                $employee->setDepartment_id($row[10]);                 
            }                             
            mysqli_free_result($rs);
            mysqli_close($cn);                
            return $employee;   
        }
        catch (Exception $ex)
        {
          echo $ex;
        }
    }      

    public function obtenerListadoEmpleados() 
    {
        $cn = Conexion::obtenerConexion();     
        $listado = array();   
        try
        {
             $rs= $cn->query("CALL spr_Listado_Employees(0)");  
             $rows = $rs->fetch_all(MYSQLI_ASSOC);
             foreach ($rows as $row) 
             {    
                $employee = new Employee();
                $employee->setEmployee_id($row["employee_id"]);
                $employee->setFirst_name($row["first_name"]);
                $employee->setLast_name($row["last_name"]);
                $employee->setEmail($row["email"]);
                $employee->setPhone_number($row["phone_number"]);
                $employee->setHire_date($row["hire_date"]);
                $employee->setJob_id($row["job_id"]);
                $employee->setSalary($row["salary"]);
                $employee->setCommission_pct($row["commission_pct"]);
                $employee->setManager_id($row["manager_id"]);
                $employee->setDepartment_id($row["department_id"]);                   
                array_push($listado, $employee);                     
             }
             mysqli_free_result($rs);
             mysqli_close($cn);
             return $listado;
        }
        catch (Exception $ex)
        {
            echo $ex;
        }   
  }

    public function guardarEmpleado($employee)
    { 
        $cn = Conexion::obtenerConexion();
        try 
        {                   
            $cn->query("SET @result = 1");
            $cn->query("CALL spr_IUEmployees('" . $employee->getEmployee_id() . "',
                                             '" . $employee->getFirst_name() . "',
                                             '" . $employee->getLast_name() . "', 
                                             '" . $employee->getEmail() . "', 
                                             '" . $employee->getPhone_number() . "', 
                                             '" . $employee->getHire_date() . "',                                         
                                             '" . $employee->getJob_id() . "', 
                                             '" . $employee->getSalary() . "',
                                             '" . $employee->getCommission_pct() . "', 
                                             '" . $employee->getManager_id() . "', 
                                             '" . $employee->getDepartment_id() . "',                                                              
                                             @result)");

            $res = $cn->query("SELECT @result AS result");
            $row = $res->fetch_assoc();
            mysqli_close($cn);
            return $row['result'];          
        }
        catch (Exception $ex)
        {
            mysqli_close($cn);  
            echo $ex;
        }
    }
  
    public function eliminarEmpleado($employee_id)
    {
        $resultado = '-1';
        $cn = Conexion::obtenerConexion();    
        try
        {         
            $cn->query("SET @result = 1");
            $cn->query("CALL spr_DEmployee('" . $employee_id . "',  @result)");
            $res = $cn->query("SELECT @result AS result");
            $row = $res->fetch_assoc();
            mysqli_close($cn);
            $resultado =  $row['result'];           
            return $resultado;
        }
        catch (Exception $ex)
        {
           mysqli_close($cn);
           echo $ex;
        }  
    }
}

?>



