<?php // Interface que expone todo lo que el DAL (Capa Acceso Datos) implementa

interface IAccesoDatos {
    public function obtenerAcceso($username, $clave);// Obtiene Acceso y permiso sobre el API 
    public function obtenerListadoEmpleados();       // Obtiene el listado de todos los Empleado
    public function obtenerEmpleado($DatoBuscar);    // Obtiene un Empleado
    public function guardarEmpleado($employee);        // Ingresa y/o actualiza un Empleado
    public function eliminarEmpleado($DatoEliminar);  // Elimina un Empleado
}
