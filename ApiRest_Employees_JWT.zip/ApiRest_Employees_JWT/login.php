<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'bll/jwt_utils.php';
require_once 'bll/Funciones.php';
require_once 'bo/Security_User.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");

if ($_SERVER['REQUEST_METHOD'] === 'POST')
{	
    $data = json_decode(file_get_contents("php://input", true));
    $controlador = Funciones::crearControlador(); 
    $user = new Security_User();
    $user =  $controlador->solicitarIngreso($data->username, $data->password); 
    if ($user != null)
    {    
        session_start();           
        $_SESSION['PerfilAcceso'] = $user->getProfile();
        $username = $user->getUsername();
        $headers = array('alg'=>'HS256','typ'=>'JWT');
        $payload = array('username'=>$username, 'exp'=>(time() + 120));
        $jwt = generate_jwt($headers, $payload);		
        echo json_encode(array('token' => $jwt));		
    } 
    else 
    {
        echo json_encode(array('Error' => 'Usuario no Valido'));
    }
}

 