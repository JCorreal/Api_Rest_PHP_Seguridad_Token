<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'bll/Jwt_Utils.php';
require_once 'bll/Funciones.php';
require_once 'bo/Security_User.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");

if ($_SERVER['REQUEST_METHOD'] === 'POST')
{	
    $data = json_decode(file_get_contents("php://input", true));
    $clave = base64_decode($data->password);
    if (is_numeric($clave) && (strlen($clave) == 6))
    {     
        $controlador = Funciones::crearControlador(); 
        $user = new Security_User();
        $user =  $controlador->solicitarIngreso($data->username, $clave); 
        if ($user->getProfile()!=null)
        {  
            $username = $user->getUsername();
            $perfil = $user->getProfile();
            $headers = array('alg'=>'HS256','typ'=>'JWT');
            $payload = array('username'=>$username, 'rol'=>$perfil, 'exp'=>(time() + 120));
            $jwt = generate_jwt($headers, $payload);		
            echo json_encode(array('token' => $jwt));		
        } 
        else 
        {
            echo json_encode(array('Error' => 'Usuario no Valido'));
        }
    }
    else
    {
      echo json_encode(array('Error' => 'Clave debe ser numerica de 6 digitos'));  
    }
}

 
