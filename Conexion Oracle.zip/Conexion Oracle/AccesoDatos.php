<?php // DAL: Data Access Layer - Capa Acceso Datos

 require_once 'bo/Employee.php';
 require_once 'bo/Security_User.php';
 require_once 'Conexion.php';
 require_once 'IAccesoDatos.php';

class AccesoDatos implements IAccesoDatos{
    
   private $cn = null;      // Alias para la Conexion 
      
    public function obtenerAcceso($username, $clave) 
    {
        $usuario = new Security_User(); 
        $cn = Conexion::obtenerConexion();
        try
        {              
            $cn = Conexion::obtenerConexion(); 
		    $rs = oci_parse($cn, "call SPR_R_OBTENERACCESO('" . $username . "', '" . $clave . "', :rc)");
            $refcur = oci_new_cursor($cn);
            oci_bind_by_name($rs, ':rc', $refcur, -1, OCI_B_CURSOR);
            oci_execute($rs);
            oci_execute($refcur); 
            while($row = oci_fetch_array($refcur, OCI_NUM)) 
            {                   
                  $usuario->setUsername($row[0][0]); 
                  $usuario->setProfile($row[0][1]);   
            }
            oci_free_statement($refcur); 
            oci_close($cn);               
            return $usuario;  
        }
        catch (Exception $ex)
        {
          echo $ex;
        }
    }
	
    public function obtenerListadoEmpleados() 
    { 
        $cn = Conexion::obtenerConexion();
        $listado = array();         
        try
        {
            $rs = oci_parse($cn, "CALL spr_Listado_Employees(0, :rc)");            
            $refcur = oci_new_cursor($cn);
            oci_bind_by_name($rs, ':rc', $refcur, -1, OCI_B_CURSOR);
            oci_execute($rs);
            oci_execute($refcur); 
            oci_execute($refcur); 
            while($row = oci_fetch_array($refcur, OCI_NUM))
            {
               array_push($listado, $row);        
            }
            oci_free_statement($refcur); 
            oci_close($cn);           
            return $listado;
        }
        catch (Exception $ex)
        {
           oci_close($cn);
           echo $ex;
        }   
    }

    public function obtenerEmpleado($employee_id) 
    {
        $employee = new Employee(); 
        $cn = Conexion::obtenerConexion();
        try
        {             
            $rs = oci_parse($cn, "CALL spr_Listado_Employees( $employee_id, :rc)");     
            $refcur = oci_new_cursor($cn);
            oci_bind_by_name($rs, ':rc', $refcur, -1, OCI_B_CURSOR);
            oci_execute($rs);
            oci_execute($refcur); 
            $employee = oci_fetch_object($refcur);    
            oci_free_statement($refcur); 
            oci_close($cn);                   
            return $employee; 
        }        
        catch (Exception $ex)
        {
          oci_close($cn);
          echo $ex;
        }
    }
    
    public function guardarEmpleado($employee)
    {
        $resultado = -1;
        $cn = Conexion::obtenerConexion();    
        try
        {                          
             $stid = oci_parse($cn, "CALL SPR_IUEMPLOYEES(  '" . $employee->getemployee_id() . "',
                                                            '" . $employee->getFirst_name() . "', 
                                                            '" . $employee->getLast_name() . "', 
                                                            '" . $employee->getEmail() . "', 
                                                            '" . $employee->getPhone_number() . "', 
                                                            '" . $employee->getHire_date() . "',    
                                                            '" . $employee->getJob_id() . "', 
                                                            '" . $employee->getSalary() . "', 
                                                            '" . $employee->getCommission_pct() . "', 
                                                            '" . $employee->getManager_id() . "', 
                                                            '" . $employee->getDepartment_id() . "', 
                                                            :result)");
            oci_bind_by_name($stid, ':result', $resultado, 2);
            oci_execute($stid);
            oci_free_statement($stid);       
            oci_close($cn);  
        }
        catch (Exception $ex)
        {
          oci_close($cn);
          echo $ex;
        }  
        return $resultado;
    } 
  
    

    public function eliminarEmpleado($employee_id)
    {
      $resultado = '-1'; 
      try
      {             
        $cn = Conexion::obtenerConexion();   
        $stid = oci_parse($cn, "CALL spr_DEMPLOYEE( '" . $employee_id . "',  :result)");
        oci_bind_by_name($stid, ':result', $resultado, 2);
        oci_execute($stid);
        oci_free_statement($stid);       
        oci_close($cn);          
        return $resultado;
      }
      catch (Exception $ex)
      {
        mysqli_close($cn);
        echo $ex;
      }  
    }
}

?>

